do
msgbox "now all ur data are crypted"
msgbox "if u want get back ur data"
msgbox "sub to adelfv. 7 on tiktok"
loop